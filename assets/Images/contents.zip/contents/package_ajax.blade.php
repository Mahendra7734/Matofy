<option value="">Select Package</option>
@foreach($data as $vs)
    <option value="{{$vs->id}}">{{$vs->name}}</option>
@endforeach