
@extends('admin.layout.admin')
@section('content')
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h3>Edit Content</h3>
                        <div class="text-right"><a href="{{ URL::to('admin/contents/content-list') }}" class="btn btn-info">Back</a>
                            <div class="ibox-tools">
                            </div>
                        </div>
                         {{ Form::open(array('url' =>'admin/contents/update-pdf/'.$contentData->id,'class'=>'form-horizontal','enctype'=>'multipart/form-data','method'=>'post')) }}
                            <input type="hidden" name="content_id" value="{{$contentData->content_id}}" class="form-control"  placeholder="Enter pdf title">                                    


                          <div class="col-sm-12">                            
                            <div class="form-group row">                                
                                <label for="inputEmail3" class="col-sm-4 form-control-label">PDF Title <span class="text-danger">*</span></label>   

                                <div class="col-sm-8">                                    
                                   <input type="text" name="pdf_title" value="{{$contentData->pdf_title}}" class="form-control"  placeholder="Enter pdf title">                                    
                                   <div class="error-message">{{ $errors->first('pdf_title') }}</div>   

                                   </div>                            
                                   </div>                        
                                   </div>

                            <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">PDF <span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="file" name="pdf" value="{{ old('pdf')}}" class="form-control"  placeholder="Enter pdf">
                                    <div class="error-message">{{ $errors->first('pdf') }}</div>
                                    <?PHP
                                      $img=empty($contentData->pdf) ? '':$contentData->pdf;
                                      ?>
                               <img src="{{ URL::asset('public/admin/uploads/pdf/'.$img) }}" height="100" width="150">
                                </div>
                            </div>
                        </div>  

                            <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Type<span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="radio" name="type" @if($contentData->type=="paid") selected @endif  value="{{$contentData->paid}}"> Paid <input @if($contentData->type=="free") selected @endif type="radio" name="type" value="{{$contentData->paid}}"> Free
                                    <div class="error-message">{{ $errors->first('pdf') }}</div>
                                </div>
                            </div>
                        </div>
                          
                        <div class="col-sm-12">                            
                            <div class="form-group row">                                
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Video Title <span class="text-danger">*</span></label>                                
                                <div class="col-sm-8">                                    
                                   <input type="text" name="video_title" value="{{$contentData->video_title}}" class="form-control"  placeholder="Enter video title">                                                                 
                                   <div class="error-message">{{ $errors->first('video_title') }}</div>

                                </div>                            
                                   </div>                        
                                   </div>
                         
                         <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Video <span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="file" name="video" value="{{ old('video')}}" class="form-control"  placeholder="Enter video">
                                    <div class="error-message">{{ $errors->first('pdf') }}</div>
                                    @if(file_exists('public/admin/uploads/video/'.$contentData->video))
                                            <img height="100" width="100" src="{{URL::to('public/admin/uploads/video/'.$contentData->video) }}" alt="{{$contentData->video}}" title="{{$contentData->image}}">
                                            @endif
                                </div>
                            </div>
                        </div>

                         <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Video Thumbnail <span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="file" name="video_thumbnail" value="{{$contentData->video_thumbnail}}" class="form-control">
                                    <div class="error-message">{{ $errors->first('video_thumbnail') }}</div>
                                      @if(file_exists('public/admin/uploads/video/'.$contentData->video_thumbnail))
                                            <img height="100" width="100" src="{{URL::to('public/admin/uploads/video/'.$contentData->video_thumbnail) }}" alt="{{$contentData->video}}" title="{{$contentData->image}}">
                                            @endif
                                </div>
                            </div>
                        </div>  

                        <div class="col-sm-12">                            
                            <div class="form-group row">                                
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Code <span class="text-danger">*</span></label>                                
                                <div class="col-sm-8">                                    
                                   <input type="text" name="link" value="{{$contentData->link}}" class="form-control"  placeholder="Enter video code">                                                                 
                                   <div class="error-message">{{ $errors->first('link') }}</div>

                                </div>                            
                                   </div>                        
                                   </div>

                        <!-- /.box-body -->
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <button type="submit" name="add_user" value="add_user" class="btn btn-primary waves-effect waves-light">
                                    Submit
                                </button>
                            </div>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    @include('admin.includes.admin_right_sidebar')
    <!-- Mainly scripts -->
        <script src="{{ URL::asset('public/admin/js/jquery-3.1.1.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/bootstrap.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/metisMenu/jquery.metisMenu.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/slimscroll/jquery.slimscroll.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/dataTables/datatables.min.js') }}"></script>
        <!-- Custom and plugin javascript -->
        <script src="{{ URL::asset('public/admin/js/inspinia.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/pace/pace.min.js') }}"></script>
        <script>
            ASSET_URL = '{{ URL::asset('public') }}/';
            BASE_URL='{{ URL::to('/') }}';
        </script>
        <script src="https://cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
        <script>
            CKEDITOR.replace( 'description' );
        </script>
        <script type="text/javascript" src="{{ URL::asset('public/admin/plugins/jquery-validation/js/jquery.validate.min.js') }}"></script>
        <script language="JavaScript" type="text/javascript" src="{{ URL::asset('public/admin/developer/js/contents.js') }}"></script>
    </div>
@stop
