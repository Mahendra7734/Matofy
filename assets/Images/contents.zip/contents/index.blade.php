<?php
/**
 * Created by PhpStorm.
 * User: wingstud
 * Date: 10/8/17
 * Time: 12:49 PM
 */
?>
@extends('admin.layout.admin')
@section('content')
<style>
    #myDIV {
      width: 100%;
      padding: 50px 0;
      /* text-align: center; */
      /* background-color: lightblue; */
      background-color: rgb(255, 255, 255);

      margin-bottom: 20px;
    }
    .filter{
        /* border:2px solid red; */
        height:80px;
        background-color: rgb(255, 255, 255);
        border:1px solid rgb(231, 230, 230);
      /* margin-bottom: 20px; */
        
    }
    .filter_text{
        font-size: 30px;
        margin: 0% 0% 0% 5%;
        padding-top:1%;
        cursor: pointer;
    }
    </style>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="filter" onclick="myFunction()">
            <div class="row">
                <div class="col-md-11">
                    <div class="filter_text">Filter</div> 
                </div>
                <div class="col-md-1">
                    <div class="filter_text" id="plus">+</div>
                     <div class="filter_text" id="minus">-</div>
                </div>
            </div>
           </div>
           <div id="myDIV">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <h3>Course</h3>
                            <select class="form-control" name="course" id="course" required onchange="getpackage(this.value)">
                                <option value="" selected>Please Select Course</option>
                                @foreach($course as $vs)
                                <option value="{{$vs->id}}">{{$vs->name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <h3>Package</h3>
                            <select class="form-control" name="package" id="package" onchange="getSubmenu(this.value)"  >
                            </select>
                        </div>
                        <div class="col-md-3">
                            <h3>Subject</h3>
                            <select class="form-control" name="submenu_id" id="submenu_id" >

                            </select>
                        </div>
                        
                    </div><br>

                    <div class="row">
                        <div class="col-md-3">
                            <button type="button" onclick="get_data_filter()" class="btn btn-info">Submit</button>
                        </div>
                    </div>
                </div>
            {{-- </form> --}}
            </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Contents List</h5>
                        <div class="text-right"><a href="{{ URL::to('admin/contents/create-content') }}" class="btn btn-info">Add New</a>
                        </div>
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table id="contents-table" class="table table-striped table-bordered table-hover dataTables-example">
                                    <thead>
                                    <tr>
                                        <th>Sr.</th>
                                        <th>Title</th>
                                        <th>Course</th>
                                        <th>Package</th>
                                        <th>Subject</th>
                                        <th>Created_at</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    @include('admin.includes.admin_right_sidebar')
    <!-- Mainly scripts -->
        <script src="{{ URL::asset('public/admin/js/jquery-3.1.1.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/bootstrap.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/metisMenu/jquery.metisMenu.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/slimscroll/jquery.slimscroll.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/dataTables/datatables.min.js') }}"></script>
        <!-- Custom and plugin javascript -->
        <script src="{{ URL::asset('public/admin/js/inspinia.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/pace/pace.min.js') }}"></script>
        <!-- Page-Level Scripts -->
        <script>
            ASSET_URL = '{{ URL::asset('public') }}/';
            BASE_URL='{{ URL::to('/') }}';
        </script>
        <script type="text/javascript" src="{{ URL::asset('public/admin/plugins/jquery-validation/js/jquery.validate.min.js') }}"></script>
        <script language="JavaScript" type="text/javascript" src="{{ URL::asset('public/admin/developer/js/contents.js') }}"></script>
        <script>
          
            $(document).ready(function(){
              $('#selectHide').hide();
              $('#myDIV').hide();
              $('#minus').hide();
             
          });
    
          function myFunction() {
      var x = document.getElementById("myDIV");
      if (x.style.display === "none") {
          x.style.display = "block";
          $('#plus').hide();
          $('#minus').show();
    
      } else {
          x.style.display = "none";
          $('#plus').show();
          $('#minus').hide();
    
    
      }
    }
    function getpackage(value)
    {
        // alert(value);
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: BASE_URL+'/admin/seller/get-sub-cat',
            type: 'POST',
            data: {id: value },
            success: function (data) {
                $("#package").html(data);
            },
            error: function () {
                console.log('There is some error in user deleting. Please try again.');
            }
        });
    }
    function getSubmenu(id){
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: BASE_URL+'/admin/contents/getquestion',
                type: 'POST',
                data: {id: id },
                success: function (data) {
                   $("#submenu_id").html(data);
                },
                error: function () {
                    console.log('There is some error in user deleting. Please try again.');
                }
            });
    }
      </script>
@stop