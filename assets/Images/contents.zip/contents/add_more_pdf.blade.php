<?php
/**
 * Created by PhpStorm.
 * User: wingstud
 * Date: 10/8/17
 * Time: 12:49 PM
 */
?>
@extends('admin.layout.admin')
@section('content')
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h3>Add More Pdf</h3>
                        <div class="text-right"><a href="{{ URL::to('admin/contents/content-list') }}" class="btn btn-info">Back</a>
                            <div class="ibox-tools">
                            </div>
                        </div>
                        {{ Form::open(array('url' =>'admin/contents/store-pdf','class'=>'form-horizontal','enctype'=>'multipart/form-data','method'=>'post')) }}
                          <input type="hidden" name="id" value="{{$content->id}}">

                          <div class="col-sm-12">                            
                            <div class="form-group row">                                
                                <label for="inputEmail3" class="col-sm-4 form-control-label">PDF Title <span class="text-danger">*</span></label>                                
                                <div class="col-sm-8">                                    
                                   <input type="text" name="pdf_title" value="{{ old('pdf_title')}}" class="form-control"  placeholder="Enter pdf title">                                    <div class="error-message">{{ $errors->first('pdf_title') }}</div>                                
                                   </div>                            
                                   </div>                        
                                   </div>

                            <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">PDF <span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="file" name="pdf" value="{{ old('pdf')}}" class="form-control"  placeholder="Enter pdf">
                                    <div class="error-message">{{ $errors->first('pdf') }}</div>
                                </div>
                            </div>
                        </div>
						
                            <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Type<span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="radio" name="type" value="paid" checked="checked"> Paid <input type="radio" name="type" value="free"> Free
                                    <div class="error-message">{{ $errors->first('pdf') }}</div>
                                </div>
                            </div>
                        </div>
                          
                        <div class="col-sm-12">                            
                            <div class="form-group row">                                
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Video Title <span class="text-danger">*</span></label>                                
                                <div class="col-sm-8">                                    
                                   <input type="text" name="video_title" value="{{ old('video_title')}}" class="form-control"  placeholder="Enter video title">                                    <div class="error-message">{{ $errors->first('pdf_title') }}</div>                                
                                   <div class="error-message">{{ $errors->first('video_title') }}</div>
                                </div>                            
                                   </div>                        
                                   </div>
                         
                         <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Video <span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="file" name="video" value="{{ old('video')}}" class="form-control"  placeholder="Enter video">
                                    <div class="error-message">{{ $errors->first('pdf') }}</div>
                                </div>
                            </div>
                        </div>



                         <div class="col-sm-12">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Video Thumbnail <span class="text-danger">*</span></label>
                                <div class="col-sm-8">
                                    <input type="file" name="video_thumbnail" value="{{ old('video_thumbnail')}}" class="form-control">
                                    <div class="error-message">{{ $errors->first('video_thumbnail') }}</div>
                                </div>
                            </div>
                        </div> 

                         <div class="col-sm-12">                            
                            <div class="form-group row">                                
                                <label for="inputEmail3" class="col-sm-4 form-control-label">Code <span class="text-danger">*</span></label>                                
                                <div class="col-sm-8">                                    
                                   <input type="text" name="link" value="{{ old('link')}}" class="form-control"  placeholder="Enter video code">                                    <div class="error-message">{{ $errors->first('link') }}</div>                                
                                   <div class="error-message">{{ $errors->first('link') }}</div>
                                </div>                            
                                   </div>                        
                                   </div>

                        <!-- /.box-body -->
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <button type="submit" name="add_user" value="add_user" class="btn btn-primary waves-effect waves-light">
                                    Submit
                                </button>
                            </div>
                        </div>
                        {{ Form::close() }}
                        
                        
                         <div class="ibox-title">
                        <h5>Pdf List</h5>
                        </div>
                        <div class="ibox-content">
                            <div class="table-responsive">
                                <table id="contents-table" class="table table-striped table-bordered table-hover dataTables-example">
                                    <thead>
                                    <tr>
                                        <th>Sr.</th>
                                        <th>PDF Title</th>
                                        <th>Video Title</th>
                                        <th>Video Thumbnail</th>
                                        <th>Created_at</th>
                                        <th>Action</th>
                                    </tr>
                                      @foreach($contentData as $ks=>$vs)
                                        <tr>
                                          <td>{{$ks+1}}</td>
                                          <td><a target="_blank" href="{{URL::to('admin/uploads/pdf/'.$vs->pdf)}}" download='download'>{{$vs->pdf_title}}</a></td>
                                          <td>{{$vs->video_title}}</td>
                                          <td>
                                            @if(file_exists('public/admin/uploads/video/'.$vs->video))
                                            <img height="100" width="100" src="{{URL::to('public/admin/uploads/video/'.$vs->video_thumbnail) }}" alt="{{$vs->video}}" title="{{$vs->image}}">
                                            @endif
                                        </td>
                                          <td>{{date("d-m-Y",strtotime($vs->created_at))}}</td>
                                          <td><a href="{{URL::to('admin/contents/delete-pdf/'.$content->id.'/'.$vs->id)}}"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;
										   @if($vs->status==0)
										  <a href="{{URL::to('admin/contents/update-status/'.$vs->id)}}"><i class="fa fa-toggle-on"></i></a>
										   @else
										   <a href="{{URL::to('admin/contents/update-status/'.$vs->id)}}"><i class="fa fa-toggle-off"></i></a>
										   @endif
										   &nbsp;&nbsp;
										   
										  <a href="{{URL::to('admin/contents/edit-pdf/'.$vs->id)}}"><i class="glyphicon glyphicon-pencil"></i></a></td>
                                        </tr>
                                      @endforeach
                                    </thead>
                                </table>
                            </div>

                        </div>
                    </div>
                    
                    </div>
                </div>
            </div>
        </div>
    @include('admin.includes.admin_right_sidebar')
    <!-- Mainly scripts -->
        <script src="{{ URL::asset('public/admin/js/jquery-3.1.1.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/bootstrap.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/metisMenu/jquery.metisMenu.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/slimscroll/jquery.slimscroll.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/dataTables/datatables.min.js') }}"></script>
        <!-- Custom and plugin javascript -->
        <script src="{{ URL::asset('public/admin/js/inspinia.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/pace/pace.min.js') }}"></script>
        <script>
            ASSET_URL = '{{ URL::asset('public') }}/';
            BASE_URL='{{ URL::to('/') }}';
        </script>
        <script src="https://cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
        <script>
            CKEDITOR.replace( 'description' );
        </script>
        </div>
@stop
