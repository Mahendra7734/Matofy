<?php
/**
 * Created by PhpStorm.
 * User: wingstud
 * Date: 10/8/17
 * Time: 12:49 PM
 */
?>
@extends('admin.layout.admin')
@section('content')
    

        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="ibox float-e-margins">
                 <div class="ibox-title clearfix">
                    <h3>View Content</h3>
                    <div class="text-right"><a href="{{ URL::to('admin/contents/content-list') }}" class="btn btn-info">Back</a>
                        <div class="ibox-tools">
                        </div>
                    </div>
                 </div>
                 <div class="ibox-content">
                    <div class="col-sm-12">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 form-control-label">Course<span class="text-danger">*</span></label>
                            <div class="col-sm-8">
                                {{!is_null($content->category)?$content->category->name:""}}
                            </div>
                        </div>
                    </div>
                     <div class="col-sm-12">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 form-control-label">Package<span class="text-danger">*</span></label>
                            <div class="col-sm-8">
                                {{ !is_null($content->package)?$content->package->name:""}}
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 form-control-label">Subject<span class="text-danger">*</span></label>
                            <div class="col-sm-8">
                                {{ !is_null($content->subject_data)?$content->subject_data->name:""}}
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-12">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 form-control-label">Title</label>
                            <div class="col-sm-8">
                                {{ $content->title }}
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    <div class="col-sm-12">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 form-control-label">Status</label>
                            <div class="col-sm-8">
                                <div class="radio">
                                    @if($content->status ==1)
                                       <b>Active</b>
                                    @else
                                        <b>InActive</b>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="col-sm-12">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 form-control-label">Description</label>
                            <div class="col-sm-8">
                                {!! $content->description !!}
                            </div>
                        </div>
                    </div>
                             
                             
                             <div class="form-group row">
                                 
                                 
                             </div>
                 </div>
             </div>
         </div>
    @include('admin.includes.admin_right_sidebar')
    <!-- Mainly scripts -->
        <script src="{{ URL::asset('public/admin/js/jquery-3.1.1.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/bootstrap.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/metisMenu/jquery.metisMenu.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/slimscroll/jquery.slimscroll.min.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/dataTables/datatables.min.js') }}"></script>
        <!-- Custom and plugin javascript -->
        <script src="{{ URL::asset('public/admin/js/inspinia.js') }}"></script>
        <script src="{{ URL::asset('public/admin/js/plugins/pace/pace.min.js') }}"></script>
        <!-- Page-Level Scripts -->
        <script>
            ASSET_URL = '{{ URL::asset('public') }}/';
            BASE_URL='{{ URL::to('/') }}';
        </script>
     </div>
@stop