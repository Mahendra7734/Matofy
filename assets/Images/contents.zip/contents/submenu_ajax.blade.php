<option value="">Select Subject</option>
@foreach($data as $vs)
    <option value="{{$vs->id}}">{{$vs->name}}</option>
@endforeach